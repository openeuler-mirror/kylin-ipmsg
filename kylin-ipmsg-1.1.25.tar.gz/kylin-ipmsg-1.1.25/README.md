# kylin-ipmsg

Provide text chat and file transfer function with no server. 


