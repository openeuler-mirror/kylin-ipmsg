#include <QApplication>
#include <QTranslator>
#include <QLocale>
#include <QStandardPaths>
#include <QLibraryInfo>
#include <QDir>
#include <fcntl.h>
#include <syslog.h>
#include <QDebug>
#include <ukui-log4qt.h>
#include <QFile>
#include <QMutex>
#include <QDateTime>
#include <sys/inotify.h>
#include <signal.h>

#include "controller/control.h"
#include "network/tcp_client.h"
#include "network/udp_socket.h"
#include "global/utils/global_data.h"
#include "global/declare/declare.h"
#include "view/kyview.h"
#include "view/common/xatom-helper.h"
#include "view/common/dbusadaptor.h"

void pipeHandler(int)
{
    qDebug() << "Info : catch signal SIGPIPE !!!";
    return;
}

int catchSig()
{
    int ret = -1;

    struct sigaction action;
    memset(&action , 0x00 , sizeof(struct sigaction));

    action.sa_handler = pipeHandler;
    sigemptyset(&action.sa_mask);
    action.sa_flags = 0;

    ret = sigaction(SIGPIPE , &action , NULL);
    if (ret) {
        qDebug()<<"Info : sigaction signal SIGPIPE fail!";
    }

    return 0;
}

int main(int argc, char *argv[])
{
    /* 统一日志输出 */
    initUkuiLog4qt("kylin-ipmsg");

    /* 适配4K屏以及分数缩放 */
    #if (QT_VERSION >= QT_VERSION_CHECK(5, 12, 0))
        QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
        QApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
    #endif
    
    #if (QT_VERSION >= QT_VERSION_CHECK(5, 14, 0))
        QApplication::setHighDpiScaleFactorRoundingPolicy(Qt::HighDpiScaleFactorRoundingPolicy::PassThrough);
    #endif

    /* 获取命令行参数 */
    if (argc > 1) {
        QString argValueStr = argv[1];
        if (argValueStr == "-d" || argValueStr == "--debug") {
            GlobalUtils::DEBUG_MODE = true;
        }
    }

    qRegisterMetaType<ChatMsgInfo>("ChatMsgInfo");
    qRegisterMetaType<ChatMsgInfo>("ChatMsgInfo&");
    qRegisterMetaType<g_tcpItem>("g_tcpItem");

    QApplication app(argc, argv);
    app.setApplicationVersion("1.2.1");
    app.setWindowIcon(QIcon::fromTheme("kylin-ipmsg"));

    /* 设置不使用gtk3平台文件对话框 */
    app.setProperty("useFileDialog", false);

    /* 连接DBus服务 */
    QDBusInterface interface(KYLIN_MESSAGES_SERVICE , KYLIN_MESSAGES_PATH , KYLIN_MESSAGES_INTERFACE , QDBusConnection::sessionBus());
    if (interface.isValid()) {
        interface.call("showMainWindow");
        return 0;
    }

    /* 文件锁实现VNC单例 */
    QStringList homePath = QStandardPaths::standardLocations(QStandardPaths::HomeLocation);
    int fd = open(QString(homePath.at(0) + "/.config/kylin-ipmsg%1.lock").arg(getenv("DISPLAY")).toUtf8().data() , O_WRONLY | O_CREAT | O_TRUNC , S_IRUSR | S_IWUSR);
    if (fd < 0) {
        exit(1);
    }

    if (lockf(fd , F_TLOCK , 0)) {
        syslog(LOG_ERR , "Can't lock single file, kylin-ipmsg is already running!");
        exit(0);
    }

    /* 加载翻译文件 */
    QString kylinIpmsgTransPath = "/usr/share/kylin-ipmsg/data/translations";
    QString peonyTransPath = "/usr/share/libpeony-qt";
    QString qtTransPath = QLibraryInfo::location(QLibraryInfo::TranslationsPath);

    QTranslator trans_global , trans_peony , trans_qt;

    if (!trans_global.load(QLocale(), "kylin-ipmsg", "_", kylinIpmsgTransPath)) {
        qDebug() << "Load global translations file" <<QLocale() << "failed!";
    } else {
        app.installTranslator(&trans_global);
    }

    if (!trans_peony.load(QLocale(), "libpeony-qt", "_", peonyTransPath)) {
        qDebug() << "Load libpeony translations file" <<QLocale() << "failed!";
    } else {
        app.installTranslator(&trans_peony);
    }

    if (!trans_qt.load(QLocale(), "qt", "_", qtTransPath)) {
        qDebug() << "Load qt translations file" <<QLocale() << "failed!";
    } else {
        app.installTranslator(&trans_qt);
    }

    /* 捕捉信号SIGPIPE */
    catchSig();

    /* 实例逻辑中心 */
    Control::getInstance();

    /* 添加窗管协议 */
    MotifWmHints hints;
    hints.flags = MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS;
    hints.functions = MWM_FUNC_ALL;
    hints.decorations = MWM_DECOR_BORDER;
    XAtomHelper::getInstance()->setWindowMotifHint(KyView::getInstance()->winId(), hints);

    KyView::getInstance()->show();
    KyView::getInstance()->checkLocalName();

    /* 创建DBus服务 */
    DbusAdaptor adaptor;
    Q_UNUSED(adaptor);

    return app.exec();
}
