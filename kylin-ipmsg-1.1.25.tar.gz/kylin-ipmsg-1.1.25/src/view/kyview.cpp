/*
 * Copyright (C) 2020, KylinSoft Co., Ltd.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "kyview.h"
#include "global/utils/inisetting.h"
#include "global/utils/addrset.h"
#include "controller/control.h"
#include <QMessageBox>

KyView::KyView(QWidget *parent)
    : QWidget(parent)
{
    // 初始化组件
    setWidgetUi();

    // 设置组件样式
    setWidgetStyle();
}

KyView::~KyView()
{
    if (GlobalUtils::DEBUG_MODE) {
        qDebug() << "~KyView()";
    }
    
    Control::getInstance()->sayGoodbye();

    LocalInfo::getInstance()->deleteLater();
    FriendListView::getInstance()->deleteLater();
    m_trayIconWid->deleteLater();

    Control::getInstance()->deleteLater();
}

// 生成静态实例
KyView *KyView::getInstance()
{   
    static KyView *instance = nullptr;
    if (nullptr == instance) {
        instance = new KyView();
    }
    return instance;
}

// 最小化状态下拉起主界面
void KyView::pullUpWindow()
{
    KWindowSystem::forceActiveWindow(this->winId());
    this->show();
}

// 初始化组件
void KyView::setWidgetUi()
{
    // 初始化并监听gsetting
    initGsetting();
   
    this->setFixedSize(WINDOWW, WINDOWH);

    // mainWid = new QWidget(this);

    m_mainLayout = new QVBoxLayout(this);

    // 标题栏
    m_titleBar = new TitleBar(this);
    m_titleBar->setFixedHeight(GlobalSizeData::TITLEBAR_HEIGHT);

    // 本机信息
    m_localInfo = LocalInfo::getInstance(this);
    m_localInfo->installEventFilter(this);

    // 好友列表
    m_friendView = FriendListView::getInstance();

    // 搜索列表
    m_searchPage = SearchPage::getInstance();
    m_searchPage->hide();

    //创建托盘图标
    m_trayIconWid = TrayIconWid::getInstance();
    // m_trayIconWid->installEventFilter(this);
    // m_trayIconWid->show();

    // 将组件添加到布局中
    m_mainLayout->addWidget(m_titleBar, Qt::AlignTop);
    m_mainLayout->addWidget(m_localInfo, Qt::AlignTop);
    m_mainLayout->addWidget(m_friendView, Qt::AlignTop);
    m_mainLayout->addWidget(m_searchPage, Qt::AlignTop);
    m_mainLayout->setMargin(0);
    m_mainLayout->setSpacing(0);

    connect(m_titleBar->m_pCloseButton, &QPushButton::clicked, this, &KyView::deleteLater);
    connect(m_localInfo->m_searchLineEdit, &QLineEdit::textChanged, this, &KyView::slotShowSearchList);
}

// 设置组件样式
void KyView::setWidgetStyle()
{
    this->setWindowTitle(tr("Messages"));

    //毛玻璃
    this->setProperty("useSystemStyleBlur",true);
    this->setAttribute(Qt::WA_TranslucentBackground,true);

    // 应用居中
    QScreen *screen = QGuiApplication::primaryScreen();
    this ->move(screen->geometry().center() - this->rect().center());

    this->update();
    m_localInfo->changeTheme();
    TrayIconWid::getInstance()->changeTheme();
}

// 初始化并监听gsetting
void KyView::initGsetting()
{
    if(QGSettings::isSchemaInstalled(UKUI_THEME_GSETTING_PATH)) {
        m_themeData = new QGSettings(UKUI_THEME_GSETTING_PATH);

        if (m_themeData->get("style-name").toString() == "ukui-dark" || 
            m_themeData->get("style-name").toString() == "ukui-black") {

            GlobalSizeData::THEME_COLOR = GlobalSizeData::UKUIDark;

        } else {
            GlobalSizeData::THEME_COLOR = GlobalSizeData::UKUILight;
        }

        connect(m_themeData,&QGSettings::changed,this,[=]()
        {
            // qDebug() << "主题颜色" << m_themeData->get("style-name").toString();
            if(m_themeData->get("style-name").toString() == "ukui-dark" || m_themeData->get("style-name").toString() == "ukui-black"){
                GlobalSizeData::THEME_COLOR = GlobalSizeData::UKUIDark;
            }
            else
            {
                GlobalSizeData::THEME_COLOR = GlobalSizeData::UKUILight;
            }
            m_localInfo->changeTheme();
            TrayIconWid::getInstance()->changeTheme();
            this->update();
        });
    }

    if (QGSettings::isSchemaInstalled(FITCONTROLTRANS)) {
        m_pGsettingControlTrans = new QGSettings(FITCONTROLTRANS);
        GlobalSizeData::BLUR_TRANSPARENCY = m_pGsettingControlTrans->get("transparency").toDouble() * 255;

        connect(m_pGsettingControlTrans,&QGSettings::changed, this, [=] (const QString &key){
            if (key == "transparency") {
                transChange();
            }
        });
    }
}

// 显示主界面后检查本机昵称
void KyView::checkLocalName()
{
    this->m_localInfo->checkLocalName();
}

// 窗口关闭事件
void KyView::closeEvent(QCloseEvent *event)
{
    Q_UNUSED(event);

    this->deleteLater();
}

// 透明度变化
void KyView::transChange()
{
    GlobalSizeData::BLUR_TRANSPARENCY = m_pGsettingControlTrans->get("transparency").toDouble() * 255;
    
    // m_titleBar->update();
    m_localInfo->update();
    m_trayIconWid->update();
}

// 绘制事件
void KyView::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);  // 反锯齿;

    // m_localInfo->update();
    // m_titleBar->update();
}

void KyView::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_F1) {
        if (!DaemonDbus::getInstance()->daemonIsNotRunning()){
            DaemonDbus::getInstance()->showGuide();
        }
    }
}

// 事件过滤器
bool KyView::eventFilter(QObject *watch, QEvent *event) {
    if (m_localInfo->eventFilter(watch, event)) {
        return QObject::eventFilter(watch, event);
    }
    return false;
}

void KyView::slotShowSearchList(QString str)
{
    if(str != "") {
        m_friendView->hide();
        m_searchPage->show();
    }else {
        m_searchPage->hide();
        m_friendView->show();
    }
}
