#ifndef __CHAT_SEARCH_FILTER_H__
#define __CHAT_SEARCH_FILTER_H__

#include <QSortFilterProxyModel>

class ChatSearchFilter : public QSortFilterProxyModel
{
    Q_OBJECT

public:
    ChatSearchFilter();
    ~ChatSearchFilter();

protected:
     bool filterAcceptsRow(int source_row , const QModelIndex &source_parent) const;
     bool judgeWhetherPicture(QString path) const;

private:

signals:

public slots:

};

#endif
