#include "chat_search_filter.h"
#include "model/chatmsgmodel.h"

ChatSearchFilter::ChatSearchFilter()
{

}

ChatSearchFilter::~ChatSearchFilter()
{

}


/*
 * pat : all:xx:xx , file:image/file:xx , word:text/link:xx
 */
bool ChatSearchFilter::filterAcceptsRow(int sourceRow , const QModelIndex &sourceParent) const
{
    QModelIndex index = sourceModel()->index(sourceRow , 0 , sourceParent);

    int msgType = index.data(ChatMsgModel::ChatMsgRoles::MsgType).toInt();
    QString chatText = index.data(ChatMsgModel::ChatMsgRoles::MsgContent).toString();
    QString filePath = index.data(ChatMsgModel::ChatMsgRoles::FilePath).toString();

    /* 过滤时间item */
    if (msgType == ChatMsgModel::MessageType::TimeMsg) {
        return false;
    }

    QRegExp a = this->filterRegExp();
    QString pat = a.pattern();
    if (pat.isEmpty()) {
        return true;
    }

    QStringList res = pat.split(':');
    if (res.count() != 3) {
        qDebug() << "Error : filter pattern erro";
        return false;
    }

    if (res.at(0) == QString("all")) {
        if (res.at(1) == QString("")) {
            if (chatText.contains(res.at(2))) {
                return true;
            }
            return false;
        } else {
            return false;
        }

    } else if (res.at(0) == QString("file")) {
        if (msgType == ChatMsgModel::MessageType::FileMsg) {
            if (res.at(1) == QString("image")) {
               if (ChatSearchFilter::judgeWhetherPicture(filePath)) {
                   return true;
               } else {
                   return false;
               }
            } else if (res.at(1) == QString("file")){
                if (!ChatSearchFilter::judgeWhetherPicture(filePath)) {
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    } else if (res.at(0) == QString("word")) {
        if (msgType == ChatMsgModel::MessageType::TextMsg) {
            if (res.at(1) == QString("link")) {
                if (chatText.contains("http")) {
                    if (res.at(2) == QString("")) {
                        return true;
                    } else {
                        if (chatText.contains(res.at(2))) {
                            return true;
                        }
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                if (res.at(1) == QString("")) {
                    if (chatText.contains(res.at(2))) {
                        return true;
                    } else {
                        return false;
                    }
                }
                else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    return false;
}

/*
 * TODO
 * if file is image return true , other return false
 */
bool ChatSearchFilter::judgeWhetherPicture(QString path) const
{
    char buf[4096];
    memset(buf , 0x00 , sizeof(buf));

    std::string stdPath = path.toStdString();
    const char *cPath = stdPath.c_str();
    sprintf(buf , "file %s" , cPath);

    FILE *fd = NULL;
    fd = popen(buf , "r");
    if (fd == NULL) {
        printf("Error : exec command fail");
        return false;
    }

    char res[4096];
    memset(res , 0x00 , sizeof(res));
    while (fgets(res , sizeof(res) , fd) != NULL) {
        if ((strstr(res , "image data") != NULL) || (strstr(res , "Matroska data") != NULL)) {
            pclose(fd);
            return true;
        }
        memset(res , 0x00 , sizeof(res));
    }

    pclose(fd);
    return false;
}
