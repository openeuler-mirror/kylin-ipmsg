<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>ChatMsg</name>
    <message>
        <source>No</source>
        <translation>མིན།</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>རེད།</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>འདྲ་ཕབ།</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>ཁ་འབྱེད།</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>སྐུར་བ།</translation>
    </message>
    <message>
        <source>Delete the currently selected message?</source>
        <translation>སུབ་པ་དང་མིག་སྔར་བདམས་ཟིན་པའི་ཟིན་ཐོ།？</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>བསུབ་པ།</translation>
    </message>
    <message>
        <source>Clear all current messages?</source>
        <translation>ཉིན་སྟོང་དང་མིག་སྔའི་ཟིན་ཐོ།？</translation>
    </message>
    <message>
        <source>Resend</source>
        <translation>བསྐྱར་སློང་།</translation>
    </message>
    <message>
        <source>Send Files</source>
        <translation>ཡིག་ཆ་གཏོང་།</translation>
    </message>
    <message>
        <source>Can not write file</source>
        <translation>ཡིག་ཆའི་ནང་བཅུག་མི་ཐུབ་པ།</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>གཞན་དུ་བཅོལ་བ།</translation>
    </message>
    <message>
        <source>Message send failed, please check whether IP connection is successful!</source>
        <translation>བརྡ་འཕྲིན་བརྒྱུད་ཕམ་བྱུང་བ།，IPདེ་སྦྲེལ་ཡོད་མེད་ལ་ཞིབ་བཤེར་བྱེད་པ།！</translation>
    </message>
    <message>
        <source>No such file or directory!</source>
        <translation>ཡིག་ཆ་འདི་དང་ཡིག་ཆའི་ནང་གནས་མེད།!</translation>
    </message>
    <message>
        <source>Send Folders</source>
        <translation>འཕྲིན་གཏོང་བཙིར་ལེན།</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation>སྟོང་བཤད་ལ་གནམ་ཐོ་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>དཀར་ཆག</translation>
    </message>
    <message>
        <source>File</source>
        <translation>ཡིག་ཆ།</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>ཡིག་ཁུག</translation>
    </message>
    <message>
        <source>Screen Shot</source>
        <translation>གཅོད་ཁྲ།</translation>
    </message>
    <message>
        <source>History Message</source>
        <translation>ལོ་རྒྱུས་ཟིན་ཐོ།</translation>
    </message>
    <message>
        <source>folder</source>
        <translation>ཡིག་ཁུག་</translation>
    </message>
</context>
<context>
    <name>ChatSearch</name>
    <message>
        <source>Chat content</source>
        <translation>བྱ་སྤྱོད་ནང་དོན།</translation>
    </message>
    <message>
        <source>Batch delete</source>
        <translation>གྲངས་བཤེར་ཅན།</translation>
    </message>
    <message>
        <source>Clear all messages</source>
        <translation>གསང་སྟོང་།</translation>
    </message>
    <message>
        <source>Chat Content</source>
        <translation>གླེང་མོལ།</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>འཚོལ་བ།</translation>
    </message>
    <message>
        <source>All</source>
        <translation>ཚང་མ</translation>
    </message>
    <message>
        <source>File</source>
        <translation>ཡིག་ཆ།</translation>
    </message>
    <message>
        <source>Image/Video</source>
        <translation>ཁ་/བརྙན་ལམ།བརྙན་ཟློས།</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>ཕྲེང་སྦྲེལ།</translation>
    </message>
    <message>
        <source>canael</source>
        <translation>འདོར་བ།</translation>
    </message>
    <message>
        <source>sure</source>
        <translation>ངེས་གཏན།</translation>
    </message>
    <message>
        <source>DeleteMenu</source>
        <translation>མིང་འདོགས་པ།</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>བསུབ་པ།</translation>
    </message>
    <message>
        <source>Choose Delete</source>
        <translation>གྲངས་བཅད་ཐོ་འགོད།</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>ཁ་འབྱེད།</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>དཀར་ཆག</translation>
    </message>
    <message>
        <source>No such file or directory!</source>
        <translation>ཡིག་ཆ་འདི་དང་ཡིག་ཆའི་ནང་གནས་མེད།!</translation>
    </message>
    <message>
        <source>Delete the currently selected message?</source>
        <translation>སུབ་པ་དང་མིག་སྔར་བདམས་ཟིན་པའི་ཟིན་ཐོ།？</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>རེད།</translation>
    </message>
    <message>
        <source>No</source>
        <translation>མིན།</translation>
    </message>
    <message>
        <source>Clear all current messages?</source>
        <translation>ཉིན་སྟོང་དང་མིག་སྔའི་ཟིན་ཐོ།？</translation>
    </message>
</context>
<context>
    <name>Control</name>
    <message>
        <source>Anonymous</source>
        <translation>རང་མིང་མི་འགོད་པ་མིང་གསང་བ་</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="obsolete">འཚོལ་བ།</translation>
    </message>
</context>
<context>
    <name>FriendInfoWid</name>
    <message>
        <source>Add</source>
        <translation>སྣོན་པ་</translation>
    </message>
    <message>
        <source>IP Address</source>
        <translation> IPགནས་ཡུལ།</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>སྤྱོད་མཁན་གྱི་མིང་།</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>གློག་ཡིག</translation>
    </message>
    <message>
        <source>Nickname</source>
        <translation>གྱི་མིང་ཐོ་འགོད་རྒྱུ།</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">ཁ་རྒྱག་པ།</translation>
    </message>
</context>
<context>
    <name>FriendListView</name>
    <message>
        <source>Cancel the Top</source>
        <translation>མེད་པར་བཟོ་མེད།</translation>
    </message>
    <message>
        <source>Set to Top</source>
        <translation>རྒྱུའི་རྩེ་མོ་འཛུགས་པ།</translation>
    </message>
    <message>
        <source>Change Nickname</source>
        <translation>མཛའ་གྲོགས་གྲ་སྒྲིག་ཡག་པོ་བྱེད་པ།</translation>
    </message>
    <message>
        <source>Start Chat</source>
        <translation>རྣམ་པ་གསར་བ།</translation>
    </message>
    <message>
        <source>View Info</source>
        <translation>ལྟ་ཞིབ་རྒྱུ་ཆ།</translation>
    </message>
    <message>
        <source>Delete Friend</source>
        <translation>ཡིའུ་ཡ།</translation>
    </message>
</context>
<context>
    <name>KyView</name>
    <message>
        <source>Messages</source>
        <translation>གློག་ཡིག</translation>
    </message>
</context>
<context>
    <name>LocalInfo</name>
    <message>
        <source>Search</source>
        <translation>འཚོལ་བ།</translation>
    </message>
    <message>
        <source>Modify Name</source>
        <translation>མིང་།</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation>དཀར་ཆག</translation>
    </message>
</context>
<context>
    <name>LocalUpdateName</name>
    <message>
        <source>Skip</source>
        <translation>མཆོང་འདས།</translation>
    </message>
    <message>
        <source>Please enter friend nickname</source>
        <translation>མཛའ་གྲོགས་གྲ་སྒྲིག་ཡག་པོ་གནང་།</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>མེད་པར་བཟོ་བ</translation>
    </message>
    <message>
        <source>Please do not enter special characters</source>
        <translation>དམིགས་བསལ་ཡིག་རྟགས།</translation>
    </message>
    <message>
        <source>Change nickname</source>
        <translation>དག་བཅོས་བྱས་པ།</translation>
    </message>
    <message>
        <source>Please enter username</source>
        <translation>ནང་འཇུག</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>གཏན་འཁེལ།</translation>
    </message>
    <message>
        <source>Set Username</source>
        <translation>སྤྱོད་མཁན་མིང་།</translation>
    </message>
    <message>
        <source>The length of user name is less than 20 words</source>
        <translation>སྤྱོད་མཁན་གྱི་མིང་གི་རིང་ཚད་དེ་ཅི་འདྲའི་ཅི་འདྲ།</translation>
    </message>
</context>
<context>
    <name>SearchMsgDelegate</name>
    <message>
        <source> relevant chat records</source>
        <translation>འབྲེལ་ཡོད་གླེང་མོལ།</translation>
    </message>
</context>
<context>
    <name>SearchPage</name>
    <message>
        <source>Start Chat</source>
        <translation>རྣམ་པ་གསར་བ།</translation>
    </message>
    <message>
        <source>Set to Top</source>
        <translation>རྒྱུའི་རྩེ་མོ་འཛུགས་པ།</translation>
    </message>
    <message>
        <source>Change Nickname</source>
        <translation>མཛའ་གྲོགས་གྲ་སྒྲིག་ཡག་པོ་བྱེད་པ།</translation>
    </message>
    <message>
        <source>View Info</source>
        <translation>ལྟ་ཞིབ་རྒྱུ་ཆ།</translation>
    </message>
    <message>
        <source>Delete Friend</source>
        <translation>ཡིའུ་ཡ།</translation>
    </message>
    <message>
        <source>Friend</source>
        <translation>གྲོགས་བཟང</translation>
    </message>
    <message>
        <source>Chat Record</source>
        <translation>གླེང་མོལ།</translation>
    </message>
</context>
<context>
    <name>TitleBar</name>
    <message>
        <source>Close</source>
        <translation>ཁ་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>ཆེས་ཆུང་འགྱུར།</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>གློག་ཡིག</translation>
    </message>
</context>
<context>
    <name>TitleSeting</name>
    <message>
        <source>No</source>
        <translation>མིན།</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>རེད།</translation>
    </message>
    <message>
        <source>Clear All Chat Messages</source>
        <translation>སྟོང་བཤད་ལ་གནམ་ཐོ་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>Clear all messages？</source>
        <translation>སྟོང་བཤད་བྱེད་དུས་སྟོང་པར་ལུས་པ་བཅས་ཀྱི་ཐོག་ནས།？</translation>
    </message>
    <message>
        <source>Change Directory</source>
        <translation>དཀར་ཆག་བཟོ་བཅོས་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>Clear the Cache</source>
        <translation>གཙང་བཤེར་དང་དལ་ཉར།</translation>
    </message>
    <message>
        <source>File Save Directory</source>
        <translation>ཡིག་ཆ་ཉར་ཚགས་བྱེད་པའི་དཀར་</translation>
    </message>
    <message>
        <source>Clean the cache information such as images/videos/documents?</source>
        <translation>དེ་གཙང་བཤེར་བྱེད་པ།/བརྙན་ལམ།བརྙན་ཟློས།/ཡིག་ཚགས་སོགས་འགྱངས་གཅོད་ཆ་འཕྲིན།？</translation>
    </message>
    <message>
        <source>Modified Successfully</source>
        <translation>བཟོ་བཅོས་བརྒྱབ་པ།</translation>
    </message>
    <message>
        <source>Cleared</source>
        <translation>གཙང་སེལ།</translation>
    </message>
    <message>
        <source>Clean Up Complete</source>
        <translation>གཙང་བཤེར་ཚར་བ།</translation>
    </message>
    <message>
        <source>Please do not save the file in this directory</source>
        <translation>ཡིག་ཆ་དེ་དཀར་ཆག་འདིའི་ནང་དུ་ཉར་ཚགས་བྱ་མི་རོགས་ཞུ་རྒྱུ་ཡིན།</translation>
    </message>
    <message>
        <source>The save path can only be a dir under the home dir!</source>
        <translation>དཀར་ཆག་ཉར་ཚགས་ནི་ཁྱིམ་གྱི་དཀར་ཆག་འོག་གི་དཀར་ཆག་ཁོ་ན་ཡིན་།!</translation>
    </message>
</context>
<context>
    <name>TrayIconWid</name>
    <message>
        <source>Ignore</source>
        <translation>སྣང་མེད་དུ་བཞག</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>གློག་ཡིག</translation>
    </message>
</context>
<context>
    <name>menuModule</name>
    <message>
        <source>Help</source>
        <translation>རོགས་རམ།</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>འདེམས་བྱང་།</translation>
    </message>
    <message>
        <source>About</source>
        <translation>འབྲེལ་ཡོད།</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>བརྗོད་གཞི།</translation>
    </message>
    <message>
        <source>Follow the Theme</source>
        <translation>བརྗོད་དོན་གཙོ་བོ།</translation>
    </message>
    <message>
        <source>Light Theme</source>
        <translation>བརྗོད་བྱ་གཙོ་བོ།</translation>
    </message>
    <message>
        <source>Service &amp; Support: </source>
        <translation>ཞབས་ཞུ།&amp;ཤོག:</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation>པར་གཞི།：</translation>
    </message>
    <message>
        <source>Messages</source>
        <translation>གློག་ཡིག</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation> སྒྲིག་འགོད།</translation>
    </message>
    <message>
        <source>Dark Theme</source>
        <translation>བརྗོད་བྱ་གཙོ་བོར་བྱེད་པ།</translation>
    </message>
    <message>
        <source>Message provides text chat and file transfer functions in the LAN. There is no need to build a server. It supports multiple people to interact at the same time and send and receive in parallel.</source>
        <translation>MenessageLANཁྲོད་ཡིག་རྐྱང་གི་འཁྲུག་ཆ་དང་འཕྲིན་གཏོང་གི་ནུས་པ་འདོན་སྤྲོད་བྱེད་ནུས།</translation>
    </message>
</context>
</TS>
