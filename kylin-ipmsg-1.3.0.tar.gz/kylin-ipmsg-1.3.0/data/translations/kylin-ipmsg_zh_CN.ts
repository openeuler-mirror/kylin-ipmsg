<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>ChatMsg</name>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="126"/>
        <source>Resend</source>
        <translation>重新发送</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="127"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="128"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="129"/>
        <source>Open Directory</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="130"/>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="957"/>
        <source>Save As</source>
        <translation>另存为</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="131"/>
        <source>Delete</source>
        <translation>删除记录</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="132"/>
        <source>Clear All</source>
        <translation>清空聊天记录</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="214"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="223"/>
        <source>Folder</source>
        <translation>文件夹</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="232"/>
        <source>Screen Shot</source>
        <translation>截图</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="241"/>
        <source>History Message</source>
        <translation>历史记录</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="259"/>
        <source>Send</source>
        <translation>发送</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="510"/>
        <source>Message send failed, please check whether IP connection is successful!</source>
        <translation>消息发送失败，请检查IP是否连接成功！</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="623"/>
        <source>Can not write file</source>
        <translation>无法写入文件</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="823"/>
        <source>No such file or directory!</source>
        <translation>此文件或文件夹不存在</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="974"/>
        <source>Delete the currently selected message?</source>
        <translation>是否删除当前所选记录？</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="977"/>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="1002"/>
        <source>No</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="1045"/>
        <source>folder</source>
        <translation>文件夹</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="976"/>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="1001"/>
        <source>Yes</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="999"/>
        <source>Clear all current messages?</source>
        <translation>是否清空当前所有记录？</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="1018"/>
        <source>Send Files</source>
        <translation>发送文件</translation>
    </message>
    <message>
        <location filename="../../src/view/chatmsg/chatmsg.cpp" line="1042"/>
        <source>Send Folders</source>
        <translation>发送文件夹</translation>
    </message>
</context>
<context>
    <name>ChatSearch</name>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="300"/>
        <source>Delete</source>
        <translation>删除记录</translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation type="obsolete">清空聊天记录</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="186"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="197"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="354"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="390"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="500"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="207"/>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="214"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="219"/>
        <source>Image/Video</source>
        <translation>图片/视频</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="227"/>
        <source>Link</source>
        <translation>链接</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="233"/>
        <source>canael</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="238"/>
        <source>sure</source>
        <translation>删除所选</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="248"/>
        <source>DeleteMenu</source>
        <translation>删除菜单</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="135"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="259"/>
        <source>Batch delete</source>
        <translation>批量删除</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="51"/>
        <source>Chat content</source>
        <translation>聊天内容</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="136"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="261"/>
        <source>Clear all messages</source>
        <translation>清空全部消息</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="169"/>
        <source>Chat Content</source>
        <translation>聊天内容</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="301"/>
        <source>Choose Delete</source>
        <translation>批量删除记录</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="302"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="303"/>
        <source>Open Directory</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="718"/>
        <source>No such file or directory!</source>
        <translation>此文件或文件夹不存在</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="770"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="955"/>
        <source>Delete the currently selected message?</source>
        <translation>是否删除当前所选记录？</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="773"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="810"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="958"/>
        <source>No</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="772"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="809"/>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="957"/>
        <source>Yes</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../../src/view/chatsearch/chat_search.cpp" line="807"/>
        <source>Clear all current messages?</source>
        <translation>是否清空当前所有记录？</translation>
    </message>
</context>
<context>
    <name>Control</name>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索</translation>
    </message>
    <message>
        <location filename="../../src/controller/control.cpp" line="336"/>
        <source>Anonymous</source>
        <translation>匿名</translation>
    </message>
</context>
<context>
    <name>FriendInfoWid</name>
    <message>
        <location filename="../../src/view/friendlist/friendinfowid.cpp" line="152"/>
        <location filename="../../src/view/friendlist/friendinfowid.cpp" line="184"/>
        <source>Messages</source>
        <translation>传书</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendinfowid.cpp" line="193"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendinfowid.cpp" line="224"/>
        <source>Username</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendinfowid.cpp" line="233"/>
        <source>IP Address</source>
        <translation>IP地址</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendinfowid.cpp" line="243"/>
        <source>Nickname</source>
        <translation>备注名</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendinfowid.cpp" line="352"/>
        <source>Add</source>
        <translation>添加备注</translation>
    </message>
</context>
<context>
    <name>FriendListView</name>
    <message>
        <location filename="../../src/view/friendlist/friendlist.cpp" line="100"/>
        <source>Start Chat</source>
        <translation>发起聊天</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendlist.cpp" line="101"/>
        <location filename="../../src/view/friendlist/friendlist.cpp" line="155"/>
        <source>Set to Top</source>
        <translation>设为置顶</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendlist.cpp" line="102"/>
        <source>Change Nickname</source>
        <translation>修改好友备注</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendlist.cpp" line="103"/>
        <source>View Info</source>
        <translation>查看资料</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendlist.cpp" line="104"/>
        <source>Delete Friend</source>
        <translation>删除好友</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/friendlist.cpp" line="158"/>
        <source>Cancel the Top</source>
        <translation>取消置顶</translation>
    </message>
</context>
<context>
    <name>KyView</name>
    <message>
        <location filename="../../src/view/kyview.cpp" line="138"/>
        <source>Messages</source>
        <translation>传书</translation>
    </message>
</context>
<context>
    <name>LocalInfo</name>
    <message>
        <location filename="../../src/view/localinfo/localinfo.cpp" line="178"/>
        <location filename="../../src/view/localinfo/localinfo.cpp" line="190"/>
        <location filename="../../src/view/localinfo/localinfo.cpp" line="265"/>
        <location filename="../../src/view/localinfo/localinfo.cpp" line="349"/>
        <location filename="../../src/view/localinfo/localinfo.cpp" line="363"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localinfo.cpp" line="163"/>
        <source>Modify Name</source>
        <translation>修改名字</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localinfo.cpp" line="172"/>
        <source>Open Directory</source>
        <translation>打开目录</translation>
    </message>
</context>
<context>
    <name>LocalUpdateName</name>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="167"/>
        <source>Set Username</source>
        <translation>设置用户名</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="168"/>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="222"/>
        <source>Please enter username</source>
        <translation>请输入用户名</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="171"/>
        <source>Change nickname</source>
        <translation>修改备注</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="172"/>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="224"/>
        <source>Please enter friend nickname</source>
        <translation>请输入好友备注</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="175"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="180"/>
        <source>Confirm</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="187"/>
        <source>Skip</source>
        <translation>跳过</translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="227"/>
        <source>The length of user name is less than 20 words</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/view/localinfo/localupdatename.cpp" line="229"/>
        <source>Please do not enter special characters</source>
        <translation>请勿输入特殊字符作为用户名</translation>
    </message>
</context>
<context>
    <name>SearchMsgDelegate</name>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/search_msg_delegate.cpp" line="43"/>
        <source> relevant chat records</source>
        <translation>条相关聊天记录</translation>
    </message>
</context>
<context>
    <name>SearchPage</name>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/searchpage.cpp" line="126"/>
        <source>Start Chat</source>
        <translation>发起聊天</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/searchpage.cpp" line="127"/>
        <source>Set to Top</source>
        <translation>设为置顶</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/searchpage.cpp" line="128"/>
        <source>Change Nickname</source>
        <translation>修改好友备注</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/searchpage.cpp" line="129"/>
        <source>View Info</source>
        <translation>查看资料</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/searchpage.cpp" line="130"/>
        <source>Delete Friend</source>
        <translation>删除好友</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/searchpage.cpp" line="159"/>
        <source>Friend</source>
        <translation>好友</translation>
    </message>
    <message>
        <location filename="../../src/view/friendlist/homepagesearch/searchpage.cpp" line="163"/>
        <source>Chat Record</source>
        <translation>聊天记录</translation>
    </message>
</context>
<context>
    <name>TitleBar</name>
    <message>
        <location filename="../../src/view/titlebar/titlebar.cpp" line="152"/>
        <source>Minimize</source>
        <translation>最小化</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titlebar.cpp" line="153"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titlebar.cpp" line="156"/>
        <source>Messages</source>
        <translation>传书</translation>
    </message>
</context>
<context>
    <name>TitleSeting</name>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="106"/>
        <source>File Save Directory</source>
        <translation>文件保存目录</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="120"/>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="239"/>
        <source>Change Directory</source>
        <translation>更改目录</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="127"/>
        <source>Clear All Chat Messages</source>
        <translation>清空聊天记录</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="134"/>
        <source>Clear the Cache</source>
        <translation>清理缓存</translation>
    </message>
    <message>
        <source>Modified successfully</source>
        <translation type="vanished">修改成功</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="259"/>
        <source>Modified Successfully</source>
        <translation>修改成功</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="297"/>
        <source>Clear all messages？</source>
        <translation>是否清空所有聊天记录？</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="300"/>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="324"/>
        <source>No</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="299"/>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="325"/>
        <source>Yes</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="246"/>
        <source>The save path can only be a dir under the home dir!</source>
        <translation>保存路径只能是家目录下的一个非隐藏目录!</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="311"/>
        <source>Cleared</source>
        <translation>已清空</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="322"/>
        <source>Clean the cache information such as images/videos/documents?</source>
        <translation>是否清理图片/视频/文档等缓存信息？</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="338"/>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="361"/>
        <source>Clean Up Complete</source>
        <translation>清理完成</translation>
    </message>
    <message>
        <source>Clean up complete</source>
        <translation type="vanished">清理完成</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="388"/>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="395"/>
        <location filename="../../src/view/titlebar/titleseting.cpp" line="405"/>
        <source>Please do not save the file in this directory</source>
        <translation>请不要将文件保存在此目录中</translation>
    </message>
</context>
<context>
    <name>TrayIconWid</name>
    <message>
        <location filename="../../src/view/trayicon/trayiconwid.cpp" line="164"/>
        <source>Ignore</source>
        <translation>忽略消息</translation>
    </message>
    <message>
        <location filename="../../src/view/trayicon/trayiconwid.cpp" line="127"/>
        <location filename="../../src/view/trayicon/trayiconwid.cpp" line="174"/>
        <source>Messages</source>
        <translation>传书</translation>
    </message>
</context>
<context>
    <name>menuModule</name>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="49"/>
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="63"/>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="157"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="65"/>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="154"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="67"/>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="151"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="69"/>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="148"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="80"/>
        <source>Follow the Theme</source>
        <translation>跟随主题</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="84"/>
        <source>Light Theme</source>
        <translation>浅色主题</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="88"/>
        <source>Dark Theme</source>
        <translation>深色主题</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="316"/>
        <source>Version: </source>
        <translation>版本号：</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="321"/>
        <source>Message provides text chat and file transfer functions in the LAN. There is no need to build a server. It supports multiple people to interact at the same time and send and receive in parallel.</source>
        <translation>麒麟传书提供局域网内的文字聊天以及文件传输功能，不需要搭建服务器，支持多人同时交互，收发并行。</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="426"/>
        <location filename="../../src/view/titlebar/menumodule.cpp" line="448"/>
        <source>Service &amp; Support: </source>
        <translation>服务与支持团队：</translation>
    </message>
    <message>
        <location filename="../../src/view/titlebar/menumodule.h" line="66"/>
        <source>Messages</source>
        <translation>传书</translation>
    </message>
</context>
</TS>
