#ifndef __GLOBAL_DATA_H__
#define __GLOBAL_DATA_H__

#include "tcp_link.h"

#include <QString>
#include <QFont>

class GlobalData
{
public:
    ~GlobalData();

    /* 本机信息 */
    QString m_uuid;
    QString m_tcpListenIP;
    QString m_tcpListenPort;
    QString m_udpListenPort;

    /* tcp链接表 */
    TcpLink m_tcpLink;
    
    /* 字体监控 */
    double m_font14pxToPt;
    double m_font12pxToPt;   /* 好友列表 信息字体 */
    double m_font16pxToPt;   /* 标题栏设置弹窗描述字体 */
    double m_font18pxToPt;   /* 聊天框 头像字体  , 主界面昵称*/

private:
    GlobalData();
public:
    static GlobalData *getInstance();

private:
    void init(void);
    void getTcpListenIp(void);
    void getTcpListenPort(void);
    void getUdpListenPort(void);
    void getUuid(void);
};

#endif

