/*
 * Copyright (C) 2020, KylinSoft Co., Ltd.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include <QTime>
#include "titleseting.h"

#include "menumodule.h"
#include "view/kyview.h"
#include "view/common/xatom-helper.h"
#include "controller/control.h"

menuModule::menuModule(QWidget *parent = nullptr) : QWidget(parent)
{
    init();
}

void menuModule::init()
{
    initAction();
    setStyle();
}

void menuModule::initAction()
{
    // aboutWindow = new QWidget();
    titleText = new QLabel();
    bodyAppName = new QLabel();
    bodyAppVersion = new QLabel();
    bodyIntroduce = new QLabel();
    bodySupport = new QLabel();
    scrollArea = new QScrollArea();

    iconSize = QSize(30,30);
    m_menuButton = new QToolButton(this);
    m_menuButton->setToolTip(tr("Menu"));
    m_menuButton->setProperty("isWindowButton", 0x1);
    m_menuButton->setProperty("useIconHighlightEffect", 0x2);
    m_menuButton->setPopupMode(QToolButton::InstantPopup);
    m_menuButton->setFixedSize(30,30);
    m_menuButton->setIconSize(QSize(16, 16));
    m_menuButton->setAutoRaise(true);
    m_menuButton->setIcon(QIcon::fromTheme("open-menu-symbolic"));
    m_menuButton->setFocusPolicy(Qt::NoFocus);

    m_menu = new QMenu();
    QList<QAction *> actions ;

    QAction *actionSetUp = new QAction(m_menu);
    actionSetUp->setText(tr("Settings"));
    QAction *actionTheme = new QAction(m_menu);
    actionTheme->setText(tr("Theme"));
    QAction *actionHelp = new QAction(m_menu);
    actionHelp->setText(tr("Help"));
    QAction *actionAbout = new QAction(m_menu);
    actionAbout->setText(tr("About"));
    actions
            << actionSetUp
            << actionHelp
            << actionAbout;

    m_menu->addActions(actions);

//    互斥按钮组
    QMenu *themeMenu = new QMenu;
    QActionGroup *themeMenuGroup = new QActionGroup(this);
    QAction *autoTheme = new QAction(tr("Follow the Theme"),this);
    themeMenuGroup->addAction(autoTheme);
    themeMenu->addAction(autoTheme);
    autoTheme->setCheckable(true);
    QAction *lightTheme = new QAction(tr("Light Theme"),this);
    themeMenuGroup->addAction(lightTheme);
    themeMenu->addAction(lightTheme);
    lightTheme->setCheckable(true);
    QAction *darkTheme = new QAction(tr("Dark Theme"),this);

    themeMenuGroup->addAction(darkTheme);
    themeMenu->addAction(darkTheme);
    darkTheme->setCheckable(true);
    QList<QAction* > themeActions;
    themeActions<<autoTheme<<lightTheme<<darkTheme;
//    autoTheme->setChecked(true);
    actionTheme->setMenu(themeMenu);
    m_menuButton->setMenu(m_menu);
    connect(m_menu,&QMenu::triggered,this,&menuModule::triggerMenu);
    initGsetting();
    setThemeFromLocalThemeSetting(themeActions);
    themeUpdate();
    connect(themeMenu,&QMenu::triggered,this,&menuModule::triggerThemeMenu);
}

void menuModule::setThemeFromLocalThemeSetting(QList<QAction* > themeActions)
{
    m_pGsettingThemeStatus = new QGSettings(confPath.toLocal8Bit());
    QString appConf = m_pGsettingThemeStatus->get("thememode").toString();
    if("lightonly" == appConf){
        themeStatus = themeLightOnly;
        themeActions[1]->setChecked(true);   //程序gsetting中为浅色only的时候就给浅色按钮设置checked
    }else if("darkonly" == appConf){
        themeStatus = themeBlackOnly;
        themeActions[2]->setChecked(true);
    }else{
        themeStatus = themeAuto;
        themeActions[0]->setChecked(true);
    }
}

void menuModule::themeUpdate(){
    if(themeStatus == themeLightOnly)
    {
        setThemeLight();
    }
    else if(themeStatus == themeBlackOnly){
        setThemeDark();
    }
    else{
        setStyleByThemeGsetting();
    }
}

void menuModule::setStyleByThemeGsetting(){
    QString nowThemeStyle = m_pGsettingThemeData->get("styleName").toString();
    if("ukui-dark" == nowThemeStyle || "ukui-black" == nowThemeStyle) {
        setThemeDark();
    }
    else {
        setThemeLight();
    }
}

void menuModule::triggerMenu(QAction *act)
{
    QString str = act->text();

    if(tr("About") == str){
        initAbout();
    }
    else if(tr("Help") == str){
        helpAction();
    }
    else if(tr("Theme") == str){
        //emit menuModuleSetThemeStyle(QString("主题"));
    }
    else if(tr("Settings") == str){
        setupAction();
    }
}

void menuModule::triggerThemeMenu(QAction *act)
{
    if(!m_pGsettingThemeStatus)
    {
        m_pGsettingThemeStatus = new QGSettings(confPath.toLocal8Bit());  //m_pGsettingThemeStatus指针重复使用避免占用栈空间
    }
    QString str = act->text();
    if("Light" == str){
        themeStatus = themeLightOnly;
        disconnect(m_pGsettingThemeData,&QGSettings::changed,this,&menuModule::dealSystemGsettingChange);
        m_pGsettingThemeStatus->set("thememode","lightonly");
//        disconnect()
        setThemeLight();
    }else if("Dark" == str){
        themeStatus = themeBlackOnly;
        disconnect(m_pGsettingThemeData,&QGSettings::changed,this,&menuModule::dealSystemGsettingChange);
        m_pGsettingThemeStatus->set("thememode","darkonly");
        setThemeDark();
    }else{
        themeStatus = themeAuto;
        m_pGsettingThemeStatus->set("thememode","auto");
        initGsetting();
//        updateTheme();
        themeUpdate();
    }
}

void menuModule::helpAction()
{
    // 帮助点击事件处理
    if(!DaemonDbus::getInstance()->daemonIsNotRunning()){
        // DaemonDbus::getInstance()->showGuide(appPath);
        DaemonDbus::getInstance()->showGuide();
    }
}

void menuModule::setupAction()
{
    TitleSeting *titleSetUp = new TitleSeting();
    titleSetUp->show();
    titleSetUp->update();
}

#include <QDialog>
void menuModule::initAbout()
{
    aboutWindow = new QWidget();
    aboutWindow->setWindowFlag(Qt::Tool);
    aboutWindow->setWindowIcon(QIcon::fromTheme("kylin-ipmsg"));
    aboutWindow->setWindowModality(Qt::WindowModal);
    aboutWindow->setWindowModality(Qt::ApplicationModal);
    // aboutWindow->setModal(true);
    // aboutWindow->setWindowFlags(Qt::FramelessWindowHint);
    MotifWmHints hints;
    // aboutWindow->setWindowFlags(Qt::WindowStaysOnTopHint);
    hints.flags = MWM_HINTS_FUNCTIONS|MWM_HINTS_DECORATIONS;
    hints.functions = MWM_FUNC_ALL;
    hints.decorations = MWM_DECOR_BORDER;
    XAtomHelper::getInstance()->setWindowMotifHint(aboutWindow->winId(), hints);

    aboutWindow->setFixedSize(420,402);
    aboutWindow->setMinimumHeight(402);

    QVBoxLayout *mainlyt = new QVBoxLayout();
    QHBoxLayout *titleLyt = initTitleBar();
    QVBoxLayout *bodylyt = initBody();

    mainlyt->setContentsMargins(0,0,0,0);
    mainlyt->setSpacing(0);
    mainlyt->addLayout(titleLyt);
    mainlyt->addLayout(bodylyt);
    mainlyt->addStretch();
    aboutWindow->setLayout(mainlyt);

    // 关于弹窗应用内居中
    QRect availableGeometry = KyView::getInstance()->geometry();
    aboutWindow->move(availableGeometry.center() - aboutWindow->rect().center());
    // aboutWindow->setStyleSheet("background-color:rgba(255,255,255,1);");

    /* 监听字体变化 */
    connect(Control::getInstance() , &Control::sigFontChange , this , [=]() {
        QFont font14;
        QFont font18;
        font14.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
        font18.setPointSizeF(GlobalData::getInstance()->m_font18pxToPt);

        this->titleText->setFont(font14);
        this->bodyAppName->setFont(font18);
        this->bodyAppVersion->setFont(font14);
        this->bodyIntroduce->setFont(font14);
        this->bodySupport->setFont(font14);
    });

    dealSystemGsettingChange("styleName");
    aboutWindow->show();
}

QHBoxLayout* menuModule::initTitleBar()
{
    QPushButton* titleIconBtn = new QPushButton(this);

    titleIconBtn->setIcon(QIcon::fromTheme("kylin-ipmsg"));
    titleIconBtn->setIconSize(QSize(24,24));
    titleIconBtn->setFixedSize(QSize(24,24));
    QString btnStyle = "QPushButton{border:0px;border-radius:4px;background:transparent;}"
                       "QPushButton:Hover{border:0px;border-radius:4px;background:transparent;}"
                       "QPushButton:Pressed{border:0px;border-radius:4px;background:transparent;}";
    titleIconBtn->setStyleSheet(btnStyle);

    QPushButton *titleBtnClose = new QPushButton;
    titleBtnClose->setFixedSize(30,30);
    titleBtnClose->setIcon(QIcon::fromTheme("window-close-symbolic"));
    titleBtnClose->setProperty("isWindowButton",0x2);
    titleBtnClose->setProperty("useIconHighlightEffect",0x8);
    titleBtnClose->setFlat(true);
    titleBtnClose->setFocusPolicy(Qt::NoFocus);
    connect(titleBtnClose,&QPushButton::clicked,[=](){aboutWindow->close();});

    titleText->setText(tr(appShowingName.toLocal8Bit()));
    QFont font;
    font.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
    titleText->setFont(font);

    QHBoxLayout *hlyt = new QHBoxLayout;
    hlyt->setSpacing(0);
    hlyt->setContentsMargins(4,4,4,4);
    hlyt->addSpacing(4);
    hlyt->addWidget(titleIconBtn); //居下显示
    hlyt->addSpacing(8);
    hlyt->addWidget(titleText);
    hlyt->addStretch();
    hlyt->addWidget(titleBtnClose);

    return hlyt;
}

QVBoxLayout* menuModule::initBody()
{

    QPushButton* bodyIcon = new QPushButton(this);
    bodyIcon->setIcon(QIcon::fromTheme("kylin-ipmsg"));
    bodyIcon->setIconSize(QSize(96,96));
    bodyIcon->setFixedSize(QSize(96,96));
    QString btnStyle = "QPushButton{border:0px;border-radius:4px;background:transparent;}"
                        "QPushButton:Hover{border:0px;border-radius:4px;background:transparent;}"
                        "QPushButton:Pressed{border:0px;border-radius:4px;background:transparent;}";
    bodyIcon->setStyleSheet(btnStyle);

    bodyAppName->setFixedHeight(40);
    bodyAppName->setText(tr(appShowingName.toLocal8Bit()));
    QFont font;
    font.setPointSizeF(GlobalData::getInstance()->m_font18pxToPt);
    bodyAppName->setFont(font);

    bodyAppVersion->setText(tr("Version: ") + appVersion);
    bodyAppVersion->setAlignment(Qt::AlignLeft);
    font.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
    bodyAppVersion->setFont(font);

    QString info = tr("Message provides text chat and file transfer functions in the LAN. "
                      "There is no need to build a server. "
                      "It supports multiple people to interact at the same time "
                      "and send and receive in parallel.");
    bodyIntroduce->setText(info);
    bodyIntroduce->setAlignment(Qt::AlignLeft);
    font.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
    bodyIntroduce->setFont(font);
    bodyIntroduce->setWordWrap(true);

    scrollArea->setFixedWidth(365);
    scrollArea->setWidget(bodyIntroduce);
    scrollArea->setWidgetResizable(true);
    scrollArea->setFrameShape(QFrame::NoFrame);
    scrollArea->setStyleSheet("QScrollArea {background-color:transparent;}");
    scrollArea->viewport()->setStyleSheet("background-color:transparent;");
    scrollArea->verticalScrollBar()->setContextMenuPolicy(Qt::NoContextMenu);

    connect(bodySupport,&QLabel::linkActivated,this,[=](const QString url){
        QDesktopServices::openUrl(QUrl(url));
    });
    bodySupport->setContextMenuPolicy(Qt::NoContextMenu);
    bodySupport->setOpenExternalLinks(true);
    font.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
    bodySupport->setFont(font);

    QVBoxLayout *vLeftLayout = new QVBoxLayout;
    vLeftLayout->setMargin(0);
    vLeftLayout->setSpacing(0);
    vLeftLayout->addWidget(scrollArea);
    vLeftLayout->addSpacing(14);
    vLeftLayout->addWidget(bodySupport);

    QHBoxLayout *hCenterLayout = new QHBoxLayout;
    hCenterLayout->setMargin(0);
    hCenterLayout->setSpacing(0);
    hCenterLayout->addStretch();
    hCenterLayout->addLayout(vLeftLayout);
    hCenterLayout->addStretch();

    QVBoxLayout *vMainLayout = new QVBoxLayout;
    vMainLayout->setMargin(0);
    vMainLayout->setSpacing(0);
    vMainLayout->addSpacing(20);
    vMainLayout->addWidget(bodyIcon, 0, Qt::AlignHCenter);
    vMainLayout->addSpacing(14);
    vMainLayout->addWidget(bodyAppName, 0, Qt::AlignHCenter);
    vMainLayout->addSpacing(12);
    vMainLayout->addWidget(bodyAppVersion, 0, Qt::AlignHCenter);
    vMainLayout->addSpacing(12);
    vMainLayout->addLayout(hCenterLayout);
    vMainLayout->addStretch();
    return vMainLayout;
}

void menuModule::setStyle()
{
    // m_menuButton->setObjectName("m_menuButton");
    // // qDebug() << "m_menuButton->styleSheet" << m_menuButton->styleSheet();
    // m_menuButton->setStyleSheet("QPushButton::menu-indicator{image:None;}");
}

void menuModule::initGsetting(){
    if(QGSettings::isSchemaInstalled(UKUI_THEME_GSETTING_PATH)){
        m_pGsettingThemeData = new QGSettings(UKUI_THEME_GSETTING_PATH);
        connect(m_pGsettingThemeData,&QGSettings::changed,this,&menuModule::dealSystemGsettingChange);
    }

}

void menuModule::keyPressEvent(QKeyEvent *event){
    if(event->key() == Qt::Key_F1){
        emit pullupHelp();
    }else{
        QWidget::keyPressEvent(event);
    }
}

void menuModule::dealSystemGsettingChange(const QString key)
{
    if(key == "styleName"){
        refreshThemeBySystemConf();
    }
}

void menuModule::refreshThemeBySystemConf()
{
    QString themeNow = m_pGsettingThemeData->get("styleName").toString();
    if("ukui-dark" == themeNow || "ukui-black" == themeNow){
        setThemeDark();
    }else{
        setThemeLight();
    }
}

void menuModule::setThemeDark()
{
    if(aboutWindow)
    {
        QPalette palette(this->palette());
        palette.setColor(QPalette::Background, QColor::fromRgb(13,13,14));
        aboutWindow->setPalette(palette);
        // aboutWindow->setStyleSheet("background-color:rgba(13,13,14,1);");
    }
    emit menuModuleSetThemeStyle("dark-theme");
    bodySupport->setText(tr("Service & Support: ") +
                         "<a href=\"mailto://support@kylinos.cn\""
                         "style=\"color:rgba(225,225,225,1)\">"
                         "support@kylinos.cn</a>");
    // m_menuButton->setProperty("setIconHighlightEffectDefaultColor", QColor(Qt::white));
    bodyAppVersion->setStyleSheet("color:#D9D9D9;");
    bodyIntroduce->setStyleSheet("color:#D9D9D9;");
    bodySupport->setStyleSheet("color:#D9D9D9;");

}

void menuModule::setThemeLight()
{
//    qDebug()<<"set theme light";
    if(aboutWindow)
    {
        QPalette palette(this->palette());
        palette.setColor(QPalette::Background, QColor::fromRgb(255,255,255));
        aboutWindow->setPalette(palette);
        // aboutWindow->setStyleSheet("background-color:rgba(255,255,255,1);");
    }
    emit menuModuleSetThemeStyle("light-theme");
    bodySupport->setText(tr("Service & Support: ") +
                         "<a href=\"mailto://support@kylinos.cn\""
                         "style=\"color:rgba(0,0,0,1)\">"
                         "support@kylinos.cn</a>");

    bodyAppVersion->setStyleSheet("color:#595959;");
    bodyIntroduce->setStyleSheet("color:#595959;");
    bodySupport->setStyleSheet("color:#595959;");

}

