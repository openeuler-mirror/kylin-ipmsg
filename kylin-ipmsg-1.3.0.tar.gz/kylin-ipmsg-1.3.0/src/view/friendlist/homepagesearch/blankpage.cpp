#include "blankpage.h"

BlankPage::BlankPage(QWidget *parent) : QWidget(parent)
{
    init();
    initGsetting();
}

BlankPage::~BlankPage()
{

}

void BlankPage::init()
{
    this->setFixedSize(QSize(350, 506));
    this->setAttribute(Qt::WA_StyledBackground,true);

//    this->setStyleSheet("background-color:#FFFFFF");
    m_blankLabel = new QLabel();
    QIcon blankIcon = QIcon(":/res/kylin-ipmsg.svg");
    m_blankLabel->setPixmap(blankIcon.pixmap(blankIcon.actualSize(QSize(100,100))));

    // 空白页面布局
    m_hBlankLayout = new QHBoxLayout();
    m_vBlankLayout = new QVBoxLayout();

    m_hBlankLayout->addStretch();
    m_hBlankLayout->addWidget(m_blankLabel);
    m_hBlankLayout->addStretch();

    m_vBlankLayout->addSpacing(160);
    m_vBlankLayout->addLayout(m_hBlankLayout);
    m_vBlankLayout->addStretch();

    this->setLayout(m_vBlankLayout);
}

void BlankPage::initGsetting()
{
    // 主题颜色
    if(QGSettings::isSchemaInstalled(UKUI_THEME_GSETTING_PATH))
    {
        m_themeData = new QGSettings(UKUI_THEME_GSETTING_PATH);

        connect(m_themeData , &QGSettings::changed , this , [=]()
        {
            if(m_themeData->get("style-name").toString() == "ukui-dark" || m_themeData->get("style-name").toString() == "ukui-black"){
                this->setStyleSheet("background-color:#000000");
            } else {
                this->setStyleSheet("background-color:#FFFFFF");
            }
        });
    }
}

void BlankPage::changeTheme()
{
    if (GlobalSizeData::THEME_COLOR == GlobalSizeData::UKUILight) {
        this->setStyleSheet("background-color:#FFFFFF");
    } else {
        this->setStyleSheet("background-color:#000000");
    }
}
