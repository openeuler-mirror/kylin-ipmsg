#include "chat_search.h"
#include "global/utils/globalutils.h"
#include "view/common/globalsizedata.h"
#include "global/utils/global_data.h"
#include "controller/control.h"

ChatSearch::ChatSearch(ChatMsg *p)
{
    this->m_chat = p;

    // 初始化组件
    setWidgetUi();

    // 设置组件样式
    setWidgetStyle();

    // 设置信号绑定
    setSignalConn();

}

ChatSearch::~ChatSearch()
{

}

// 单例，初始化返回指针
ChatSearch* ChatSearch::getInstance(ChatMsg *chat)
{
    static ChatSearch *instance = nullptr;

    if (instance == nullptr) {
        try {
            instance = new ChatSearch(chat);
        }
        catch (const std::runtime_error &re)
        {
            qDebug() << "runtime_error:" << re.what();
        }
    }

    return instance;
}

// 初始化组件
void ChatSearch::setWidgetUi()
{
    // 初始化并监听gsetting
    initGsetting();

    this->setWindowTitle(tr("Chat content"));

    // 初始化组件和布局
    m_titleBar          = new TitleBar(false, false, false);
    m_searchAreaWid     = new QWidget(this);
    m_chooseDeleWid     = new QLabel(this);
    m_searchIconLab     = new QLabel(this);
    m_searchLineEdit    = new QLineEdit(this);
    m_allBtn            = new QPushButton(this);
    m_fileBtn           = new QPushButton(this);
    m_ImageBtn          = new QPushButton(this);
    m_linkBtn           = new QPushButton(this);
    m_deleMenuBtn       = new QToolButton(this);
    m_cancelDeleBtn     = new QPushButton(this);
    m_sureDeleBtn       = new QPushButton(this);
    m_listView          = new QListView(this);
    m_mainLayout        = new QVBoxLayout();
    m_searchAreaVLayout = new QVBoxLayout();
    m_searchAreaHLayout = new QHBoxLayout(m_searchAreaWid);
    m_searchLayout      = new QHBoxLayout(this);
    m_funcBtnLayout     = new QHBoxLayout(this);
    m_deleleBtnLayout   = new QHBoxLayout(this);
    m_deleleAreaLayout  = new QHBoxLayout(this);
    m_deleFuncMenu      = new QMenu(this);
    m_funcMenu          = new QMenu(this);

    // 将组件放入布局
    //搜索区域布局
    m_searchLayout->addWidget(m_searchIconLab);
    m_searchLayout->addStretch();
    m_searchLayout->setSpacing(0);/*各部件的相邻距离*/
    m_searchLayout->setContentsMargins(0, 0, 0, 0);
    m_searchLineEdit->setLayout(m_searchLayout);

    this->installEventFilter(this);//安装过滤器，进行函数过滤,使图标进行移动
    m_searchLineEdit->installEventFilter(this);//安装过滤器，进入函数eventFilter
    m_allBtn->installEventFilter(this);
    m_fileBtn->installEventFilter(this);
    m_ImageBtn->installEventFilter(this);
    m_linkBtn->installEventFilter(this);
    m_listView->installEventFilter(this);

    // 功能按钮布局
    m_funcBtnLayout->addSpacing(0);
    m_funcBtnLayout->addWidget(m_allBtn);
    m_funcBtnLayout->addWidget(m_fileBtn);
    m_funcBtnLayout->addWidget(m_ImageBtn);
    m_funcBtnLayout->addWidget(m_linkBtn);
    m_funcBtnLayout->addStretch();

    m_funcBtnLayout->addWidget(m_cancelDeleBtn);
    m_funcBtnLayout->addSpacing(16);
    m_funcBtnLayout->addWidget(m_sureDeleBtn);
    m_funcBtnLayout->addWidget(m_deleMenuBtn);
    m_funcBtnLayout->setMargin(0);
    m_funcBtnLayout->setSpacing(1);

    // 搜索区域纵向布局
    m_searchAreaVLayout->addWidget(m_searchLineEdit);
    m_searchAreaVLayout->addSpacing(16);
    m_searchAreaVLayout->addLayout(m_funcBtnLayout);
    m_searchAreaVLayout->setMargin(0);
    m_searchAreaVLayout->setSpacing(0);

    // 搜索区域横向布局
    m_searchAreaHLayout->addStretch();
    m_searchAreaHLayout->addLayout(m_searchAreaVLayout);
    m_searchAreaHLayout->addStretch();

    //信息展示区域（删除显现）
    m_deleleAreaLayout->addWidget(m_chooseDeleWid);
    m_deleleAreaLayout->addWidget(m_listView);
    m_deleleAreaLayout->setMargin(0);
    m_deleleAreaLayout->setSpacing(0);

    // 总体布局
    m_mainLayout->addWidget(m_titleBar);
    m_mainLayout->addWidget(m_searchAreaWid);
    m_mainLayout->addLayout(m_deleleAreaLayout);
    m_mainLayout->setMargin(0);
    m_mainLayout->setSpacing(0);

    // 删除按钮菜单
    m_funcMenu = new QMenu(this);
    m_deleteMsgAction = m_funcMenu->addAction(tr("Batch delete"));
    m_clearMsgAction  = m_funcMenu->addAction(tr("Clear all messages"));

    this->setLayout(m_mainLayout);

    // 设置窗口页面居中
    QScreen *screen = QGuiApplication::primaryScreen();
    this->move(screen->geometry().center() - this->rect().center());

}

// 设置组件样式
void ChatSearch::setWidgetStyle()
{
    //毛玻璃
    // this->setProperty("useSystemStyleBlur",true);
    // this->setAttribute(Qt::WA_TranslucentBackground,true);

    // 主界面属性
#ifdef __V10Pro__
    // 添加窗管协议
    MotifWmHints hints;
    hints.flags = MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS;
    hints.functions = MWM_FUNC_ALL;
    hints.decorations = MWM_DECOR_BORDER;
    XAtomHelper::getInstance()->setWindowMotifHint(this->winId(), hints);
#endif

    this->setFixedSize(QSize(500, 680));
    this->setMouseTracking(true);


    // 设置标题栏属性
    m_titleBar->m_pIconBtn->hide();
    m_titleBar->setTitleText(tr("Chat Content"));
    m_titleBar->setAutoFillBackground(true);
    m_titleBar->setBackgroundRole(QPalette::Base);

    //设置搜索窗口界面的大小
    m_searchAreaWid->setFixedSize(QSize(500, 120));

    // 设置搜索区域属性
    m_searchAreaWid->setAutoFillBackground(true);
    m_searchAreaWid->setBackgroundRole(QPalette::Base);

    m_searchLineEdit->setFixedSize(468, 36);
    QFont font;
    font.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
    m_searchLineEdit->setFont(font);
    QFontMetrics lineFontMetr = QFontMetrics(font);
    //组件大小
    m_searchIconLab->setFixedSize(m_searchLineEdit->width()/2 - lineFontMetr.width(tr("Search"))/ 2 + 10, m_searchLineEdit->height());

    QIcon searchIcon = QIcon::fromTheme("edit-find-symbolic");
    m_searchIconLab->setPixmap(searchIcon.pixmap(searchIcon.actualSize(QSize(20,20))));
    m_searchIconLab->setProperty("isWindowButton", 0x1);
    m_searchIconLab->setProperty("useIconHighlightEffect", 0x2);
    m_searchIconLab->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
    m_searchIconLab->setAttribute(Qt::WA_TranslucentBackground, true);

    QMargins margins = m_searchLineEdit->textMargins();
    m_searchLineEdit->setTextMargins(margins.left(), margins.top(), m_searchIconLab->width(), margins.bottom());
    m_searchLineEdit->setPlaceholderText(tr("Search"));//提示文字
    m_searchLineEdit->setMaxLength(30);//字数限制
    m_searchLineEdit->setTextMargins(m_searchIconLab->width(), 1, 1 , 1);// 设置输入框中文件输入区，不让输入的文字在被隐藏在按钮下
    m_searchLineEdit->setContextMenuPolicy(Qt::NoContextMenu);

    // 选择全部按钮
    QFont btnFont = this->font();
    btnFont.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
    m_allBtn->setFont(btnFont);
    m_allBtn->setFixedSize(QSize(72, 36));
    m_allBtn->setText(tr("All"));
    m_allBtn->setProperty("isImportant", true);
    m_allBtn->setFocus();

    // 文件按钮
    m_fileBtn->setFont(btnFont);
    m_fileBtn->setFixedSize(QSize(72, 36));
    m_fileBtn->setText(tr("File"));
    m_fileBtn->setFlat(true);

    // 图片/视频按钮
    m_ImageBtn->setFont(btnFont);
    m_ImageBtn->setText(tr("Image/Video"));
    QFontMetrics fontmts = QFontMetrics(m_ImageBtn->font());
    m_ImageBtn->setFixedSize(fontmts.width(m_ImageBtn->text()) + 35, 36);
    m_ImageBtn->setFlat(true);

    // 链接按钮
    m_linkBtn->setFont(btnFont);
    m_linkBtn->setFixedSize(QSize(72, 36));
    m_linkBtn->setText(tr("Link"));
    m_linkBtn->setFlat(true);

    // 删除中取消按钮
    m_cancelDeleBtn->setFont(btnFont);
    m_cancelDeleBtn->setFixedSize(QSize(96, 36));
    m_cancelDeleBtn->setText(tr("canael"));
    m_cancelDeleBtn->hide();

    // 删除中确定按钮
    m_sureDeleBtn->setFont(btnFont);
    m_sureDeleBtn->setText(tr("sure"));
    fontmts = QFontMetrics(m_sureDeleBtn->font());
    m_sureDeleBtn->setFixedSize(fontmts.width(m_sureDeleBtn->text()) + 65, 36);
    m_sureDeleBtn->setProperty("isImportant", true);
    m_sureDeleBtn->hide();

    // 删除菜单按钮
    m_deleMenuBtn->setFixedSize(QSize(25, 25));
    m_deleMenuBtn->setIconSize(QSize(16, 16));
    m_deleMenuBtn->setIcon(QIcon::fromTheme("view-more-horizontal-symbolic"));
    m_deleMenuBtn->setToolTip(tr("DeleteMenu"));
    m_deleMenuBtn->setPopupMode(QToolButton::InstantPopup);
    m_deleMenuBtn->setProperty("isWindowButton", 0x1);
    m_deleMenuBtn->setProperty("useIconHighlightEffect", 0x2);
    m_deleMenuBtn->setAutoRaise(true);
    m_deleMenuBtn->setFocusPolicy(Qt::NoFocus);

    QList<QAction *> actions ;

    //设置菜单中的按键
    m_deleteMsgAction = new QAction(m_deleFuncMenu);
    m_deleteMsgAction->setText(tr("Batch delete"));
    m_clearMsgAction = new QAction(m_deleFuncMenu);
    m_clearMsgAction->setText(tr("Clear all messages"));
    actions
            << m_deleteMsgAction
            << m_clearMsgAction;

    m_deleFuncMenu->addActions(actions);
    m_deleMenuBtn->setMenu(m_deleFuncMenu);

    //选择删除的列表
    m_chooseDeleWid->setFixedSize(25, 520);
    m_chooseDeleWid->hide();

    m_listView->setAutoFillBackground(true);
    //设置聊天记录中的属性
    m_chatSearchDelegate = new ChatSearchDelegate(this->m_chat,this);
    m_listView->setItemDelegate(m_chatSearchDelegate);

    m_chatFiler = new ChatSearchFilter();
    m_chatFiler->setSourceModel(this->m_chat->m_chatMsgModel);
    m_chatFiler->setDynamicSortFilter(true);
    m_chatFiler->sort(0);
    m_chatFiler->setFilterKeyColumn(0);
    m_listView->setModel(this->m_chatFiler);

    m_listView->setFixedHeight(520);
    //m_listView->setSpacing(7);
    m_listView->setDragEnabled(false);
    m_listView->setFrameShape(QListView::NoFrame);
    m_listView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_listView->setContextMenuPolicy(Qt::CustomContextMenu);
    m_listView->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    m_listView->verticalScrollBar()->setProperty("drawScrollBarGroove", false);
    m_listView->scrollToBottom();
    m_listView->verticalScrollBar()->setContextMenuPolicy(Qt::NoContextMenu);

    changeTheme();

    // 右键菜单
    m_funcMenu = new QMenu(this);
    m_oneDeleAction    = m_funcMenu->addAction(tr("Delete"));
    m_chooseDeleAction = m_funcMenu->addAction(tr("Choose Delete"));
    m_openFileAction   = m_funcMenu->addAction(tr("Open"));
    m_openDirAction    = m_funcMenu->addAction(tr("Open Directory"));

}

// 初始化并监听gsetting
void ChatSearch::initGsetting()
{
    // 主题颜色
    if(QGSettings::isSchemaInstalled(UKUI_THEME_GSETTING_PATH))
    {
        m_themeData = new QGSettings(UKUI_THEME_GSETTING_PATH);

        connect(m_themeData,&QGSettings::changed,this,[=]()
        {
            if(m_themeData->get("style-name").toString() == "ukui-dark" || m_themeData->get("style-name").toString() == "ukui-black"){
                m_chooseDeleWid->setStyleSheet("background-color:#333333;");
                m_listView->setStyleSheet("QListView{background:#333333;}");

                if (!m_chooseDeleWid->isHidden()) {
                    QString listStyle = "QListWidget{background-color:#333333;}"
                                        "QListWidget::item:hover{background-color:#333333;}"
                                        "QListWidget::item::selected:active{background-color:#333333;border-width:0;}"
                                        "QListWidget::item:selected{background-color:#333333;border-width:0;}";
                    m_chooseListWid->setStyleSheet(listStyle);
                }

            } else {
                m_chooseDeleWid->setStyleSheet("background-color:#FFFFFF;");
                m_listView->setStyleSheet("QListView{background:#FFFFFF;}");

                if (!m_chooseDeleWid->isHidden()) {
                    QString listStyle = "QListWidget{background-color:#FFFFFF;}"
                                        "QListWidget::item:hover{background-color:#FFFFFF;}"
                                        "QListWidget::item::selected:active{background-color:#FFFFFF;border-width:0;}"
                                        "QListWidget::item:selected{background-color:#FFFFFF;border-width:0;}";
                    m_chooseListWid->setStyleSheet(listStyle);
                }
            }
        });
    }

}

//还原文本框初始状态
void ChatSearch::restoreLineEdit()
{
    m_searchLineEdit->clear();
    QFont font;
    font.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);
    m_searchLineEdit->setFont(font);
    QFontMetrics lineFontMetr = QFontMetrics(font);
    m_searchIconLab->setFixedSize(m_searchLineEdit->width()/2 - lineFontMetr.width(tr("Search"))/ 2 + 10, m_searchLineEdit->height());
    m_searchIconLab->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
    m_searchLineEdit->setAlignment(Qt::AlignLeft);
    m_searchLineEdit->setTextMargins(m_searchIconLab->width(), 1, 1, 1);
    m_searchLineEdit->clearFocus();
}

void ChatSearch::changeTheme()
{
    if (GlobalSizeData::THEME_COLOR == GlobalSizeData::UKUILight) {
        m_chooseDeleWid->setStyleSheet("background-color:#FFFFFF;");
        m_listView->setStyleSheet("QListView{background:#FFFFFF;}");

    } else {
        m_chooseDeleWid->setStyleSheet("background-color:#333333;");
        m_listView->setStyleSheet("QListView{background:#333333;}");
    }
}

//对控件接收到的事件进行过滤
bool ChatSearch::eventFilter(QObject *watch,QEvent *e)
{
    if ((e->type() == QEvent::MouseButtonPress && watch !=  m_searchLineEdit) ||
        (e->type() == QEvent::FocusOut && watch ==  m_searchLineEdit)){
        if (m_searchLineEdit->text() == "") {
            restoreLineEdit();
            changeTheme();
        }

    }
    if((e->type() == QEvent::MouseButtonPress && watch ==  m_searchLineEdit) ||
        (e->type() == QEvent::FocusIn && watch ==  m_searchLineEdit)){
        m_searchIconLab->setFixedSize(30, 30);
        m_searchLineEdit->setAlignment(Qt::AlignLeft);
        m_searchLineEdit->setTextMargins(m_searchIconLab->width(), 1, 1 , 1);
        m_searchLineEdit->setFocus();
        m_searchLineEdit->setPlaceholderText(tr("Search"));//提示文字
    }
    if(e->type() == QEvent::MouseButtonPress && watch ==  m_allBtn){
        m_allBtn->setProperty("isImportant", true);
        m_allBtn->setFlat(false);
        m_fileBtn->setFlat(true);
        m_ImageBtn->setFlat(true);
        m_linkBtn->setFlat(true);
        m_allClick = true;
        m_fileClick = false;
        m_imageClick = false;
        m_linkClick = false;
        restoreLineEdit();

    }else if(e->type() == QEvent::MouseButtonPress && watch ==  m_fileBtn){
        m_fileBtn->setProperty("isImportant", true);
        m_allBtn->setFlat(true);
        m_fileBtn->setFlat(false);
        m_ImageBtn->setFlat(true);
        m_linkBtn->setFlat(true);
        m_allClick = false;
        m_fileClick = true;
        m_imageClick = false;
        m_linkClick = false;
        restoreLineEdit();

    }else if(e->type() == QEvent::MouseButtonPress && watch ==  m_ImageBtn){
        m_ImageBtn->setProperty("isImportant", true);
        m_allBtn->setFlat(true);
        m_fileBtn->setFlat(true);
        m_ImageBtn->setFlat(false);
        m_linkBtn->setFlat(true);
        m_allClick = false;
        m_fileClick = false;
        m_imageClick = true;
        m_linkClick = false;
        restoreLineEdit();

    }else if(e->type() == QEvent::MouseButtonPress && watch ==  m_linkBtn){
        m_linkBtn->setProperty("isImportant", true);
        m_allBtn->setFlat(true);
        m_fileBtn->setFlat(true);
        m_ImageBtn->setFlat(true);
        m_linkBtn->setFlat(false);
        m_allClick = false;
        m_fileClick = false;
        m_imageClick = false;
        m_linkClick = true;
        restoreLineEdit();

    }

    return QObject::eventFilter(watch,e);
}

void ChatSearch::closeEvent(QCloseEvent *event)
{
    Q_UNUSED(event);
    emit sigCloseSearchWid();
    return;
}

// 设置信号绑定
void ChatSearch::setSignalConn()
{
    connect(m_titleBar->m_pCloseButton, &QPushButton::clicked, this, &ChatSearch::close);

    connect(m_allBtn,        &QPushButton::clicked, this, &ChatSearch::showAllInfo);
    connect(m_fileBtn,       &QPushButton::clicked, this, &ChatSearch::showFileInfo);
    connect(m_ImageBtn,      &QPushButton::clicked, this, &ChatSearch::showImageInfo);
    connect(m_linkBtn,       &QPushButton::clicked, this, &ChatSearch::showLinkInfo);
    connect(m_deleMenuBtn,   &QToolButton::clicked, this, &ChatSearch::showDeleMenu);
    connect(m_cancelDeleBtn, &QPushButton::clicked, this, &ChatSearch::slotCancelClick);
    connect(m_sureDeleBtn,   &QPushButton::clicked, this, &ChatSearch::slotSureClick);

    connect(m_listView, &QListView::customContextMenuRequested, this, &ChatSearch::showContextMenu);
    connect(m_listView, SIGNAL(clicked (const QModelIndex &)),this,SLOT(slotChooseMsg(const QModelIndex &)));

    connect(m_listView->verticalScrollBar(), SIGNAL(valueChanged(int)), this, SLOT(onSliderMoved(int)));

    //菜单按钮中点击
    connect(m_deleteMsgAction, &QAction::triggered, this, &ChatSearch::showChooseMsg);
    connect(m_clearMsgAction,  &QAction::triggered, this, &ChatSearch::slotClearMsg);

    //右键菜单中的点击
    connect(m_chooseDeleAction, &QAction::triggered, this, &ChatSearch::showChooseMsg);
    connect(m_oneDeleAction,    &QAction::triggered, this, &ChatSearch::slotDeleteMsg);
    connect(m_openFileAction,   &QAction::triggered, this, &ChatSearch::slotOpenFile);
    connect(m_openDirAction,    &QAction::triggered, this, &ChatSearch::slotOpenDir);

    connect(m_searchLineEdit, &QLineEdit::textChanged, this, &ChatSearch::filterFriendByReg);

    /* 监听字体变化 */
    connect(Control::getInstance() , &Control::sigFontChange , this , [=]() {
        QFont font14;
        font14.setPointSizeF(GlobalData::getInstance()->m_font14pxToPt);

        m_titleBar->m_pFuncLabel->setFont(font14);
        m_searchLineEdit->setFont(font14);
        m_allBtn->setFont(font14);
        m_fileBtn->setFont(font14);
        m_ImageBtn->setFont(font14);
        m_linkBtn->setFont(font14);
        m_deleMenuBtn->setFont(font14);
        m_cancelDeleBtn->setFont(font14);
        m_sureDeleBtn->setFont(font14);

        if (m_searchLineEdit->text() == "") {
            QFontMetrics fontmts = QFontMetrics(font14);
            m_ImageBtn->setFixedSize(fontmts.width(m_ImageBtn->text()) + 30, 36);
            m_searchIconLab->setFixedSize(m_searchLineEdit->width()/2 - fontmts.width(tr("Search"))/ 2 + 10, m_searchLineEdit->height());
            m_searchLineEdit->setTextMargins(m_searchIconLab->width(), 1, 1, 1);
        }

    });

    return;
}

//控制两个list一起滚动
void ChatSearch::onSliderMoved(int pos)
{
    if (!m_chooseDeleWid->isHidden()) {
        m_chooseListWid->verticalScrollBar()->setValue(pos);
    }

    m_listView->verticalScrollBar()->setValue(pos);
}

// 滚动条是否在底端
bool ChatSearch::isScrollOnBottom()
{
    if (m_listView->verticalScrollBar()->value() == m_listView->verticalScrollBar()->maximum()) {
        if (!m_chooseDeleWid->isHidden()) {
            if (m_chooseListWid->verticalScrollBar()->value() == m_chooseListWid->verticalScrollBar()->maximum()) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }
    return false;
}

// 滚动条设为底端
void ChatSearch::setScrollToBottom()
{
    if (!m_chooseDeleWid->isHidden()) {
        m_chooseListWid->scrollToBottom();
    }

    m_listView->scrollToBottom();
}

// 根据字符串过虑聊天记录
void ChatSearch::filterFriendByReg(QString searchStr)
{
    QString regStr;
    regStr.clear();

    if (m_allClick) {
        regStr = QString("all:") + searchStr;
    } else if (m_fileClick) {
        regStr = QString("file:") + searchStr;
    } else if (m_imageClick) {
        regStr = QString("image:") + searchStr;
    } else if (m_linkClick) {
        regStr = QString("link:") + searchStr;
    }

    m_searchText = searchStr;

    m_chatFiler->setFilterRegExp(QRegExp(regStr , Qt::CaseInsensitive , QRegExp::FixedString));

    m_listView->update();

    if (!m_chooseDeleWid->isHidden()) {
        showDeleMsgCheckbox();
    }

    this->setScrollToBottom();

    return;
}

// 获取焦点
void ChatSearch::getFocus()
{
    if (this->isHidden()) {
        m_listView->scrollToBottom();
    }

}

//选择全部信息
void ChatSearch::showAllInfo()
{
    //设置聊天记录中的属性
    QString regStr;
    regStr.clear();
    regStr = QString("all:") ;

    m_chatFiler->setFilterRegExp(QRegExp(regStr, Qt::CaseInsensitive, QRegExp::FixedString));

    //从底部开始显示
    setScrollToBottom();

    return ;
}

//选择文件类型的信息
void ChatSearch::showFileInfo()
{
    if (m_searchLineEdit->text() == "") {
        QString regStr;
        regStr.clear();

        regStr = QString("file:");

        m_chatFiler->setFilterRegExp(QRegExp(regStr, Qt::CaseInsensitive, QRegExp::FixedString));

    } else {
        filterFriendByReg(m_searchLineEdit->text());
    }

    //从底部开始显示
    setScrollToBottom();

    return ;
}

//选择图片/视频类型的信息
void ChatSearch::showImageInfo()
{
    if(m_searchLineEdit->text() == ""){
        QString regStr;
        regStr.clear();

        regStr = QString("image:") ;

        m_chatFiler->setFilterRegExp(QRegExp(regStr, Qt::CaseInsensitive, QRegExp::FixedString));

    }else {
        filterFriendByReg(m_searchLineEdit->text());
    }

    //从底部开始显示
    setScrollToBottom();

    return ;
}

//选择链接类型的信息

void ChatSearch::showLinkInfo()
{
    if(m_searchLineEdit->text() == ""){
        QString regStr;
        regStr.clear();

        regStr = QString("link:");

        m_chatFiler->setFilterRegExp(QRegExp(regStr, Qt::CaseInsensitive, QRegExp::FixedString));

    } else {
        filterFriendByReg(m_searchLineEdit->text());
    }

    //从底部开始显示
    setScrollToBottom();

    return ;
}

// 点击菜单按钮
void ChatSearch::showDeleMenu()
{
    m_deleteMsgAction->setVisible(true);
    m_clearMsgAction->setVisible(true);
}

// 显示右键菜单
void ChatSearch::showContextMenu(const QPoint& point)
{
    Q_UNUSED(point);
    if (m_chooseDeleWid->isHidden()) {
        if (!((m_listView->selectionModel()->selectedIndexes()).empty())) {

            // 将代理index转换为消息index
            QModelIndex msgIndex = m_listView->currentIndex();
            int msgType  = msgIndex.data(ChatMsgModel::MsgType).toInt();

            if (msgType == ChatMsgModel::MessageType::TextMsg) {

                m_oneDeleAction->setVisible(true);
                m_chooseDeleAction->setVisible(true);
                m_openFileAction ->setVisible(false);
                m_openDirAction->setVisible(false);

            }else if (msgType == ChatMsgModel::MessageType::TimeMsg) {

                m_oneDeleAction->setVisible(false);
                m_chooseDeleAction->setVisible(false);
                m_openFileAction ->setVisible(false);
                m_openDirAction->setVisible(false);

            }else {
                m_oneDeleAction->setVisible(true);
                m_chooseDeleAction->setVisible(true);
                m_openFileAction ->setVisible(true);
                m_openDirAction->setVisible(true);
            }

            m_funcMenu->exec(QCursor::pos());
            m_listView->selectionModel()->clear();
            return ;
        }
    } else {
        return;
    }

}

// 检查文件和文件夹是否存在
bool ChatSearch::checkFileExist(QString filePath)
{
    if (!QFileInfo::exists(filePath)) {
        QMessageBox::critical(this, "", tr("No such file or directory!"));
        return false;
    }

    return true;
}

// 使用默认应用打开文件或文件夹
void ChatSearch::slotOpenFile()
{
    QModelIndex msgIndex = m_listView->currentIndex();

    // 获取消息数据
    QString filePath = msgIndex.data(ChatMsgModel::FilePath).toString();

    if (!checkFileExist(filePath)) {
        return ;
    }

    filePath = QString("file://") + filePath;
    bool is_open = QDesktopServices::openUrl(QUrl(filePath, QUrl::TolerantMode));

    if (!is_open) {
        qDebug() << "open by xdg";
        QString cmd = QString("xdg-open ") + filePath;
        QProcess::execute(cmd);
    }
}

// 打开所在目录
void ChatSearch::slotOpenDir()
{
    QModelIndex msgIndex = m_listView->currentIndex();

    // 获取消息数据
    QString filePath = msgIndex.data(ChatMsgModel::FilePath).toString();

    if (!checkFileExist(filePath)) {
        return ;
    }

    QString pathCmd = "\"" + filePath + "\"";
    QString cmd = QString("peony --show-items " + pathCmd);

    QProcess::execute(cmd);
}

// 删除消息
void ChatSearch::slotDeleteMsg()
{
    QMessageBox *msg = new QMessageBox(this);
    msg->setWindowTitle(tr(""));
    msg->setText(tr("Delete the currently selected message?"));
    msg->setIcon(QMessageBox::Question);
    QPushButton *sureBtn = msg->addButton(tr("Yes"),QMessageBox::RejectRole);
    msg->addButton(tr("No"),QMessageBox::AcceptRole);
    msg->exec();

    if((QPushButton*)msg->clickedButton() != sureBtn) {

        return ;
    }
    //获取当前选择的索引
    QModelIndex searchIndex = m_listView->currentIndex();

    // 获取消息ID号
    int searchMsgId = searchIndex.data(ChatMsgModel::MsgId).toInt();

    //循环找到在model中的索引
    for(int i = 0; i < this->m_chat->m_chatMsgModel->rowCount(); i++)
    {
        QModelIndex msgIndex = this->m_chat->m_chatMsgModel->index(i,0);
        int mId = msgIndex.data(ChatMsgModel::MsgId).toInt();

        if(mId == searchMsgId){
            this->m_chat->m_chatMsgModel->delChatMsg(searchMsgId, msgIndex.row());
            break;
        }
    }

    return ;

}

// 清空消息
void ChatSearch::slotClearMsg()
{
    QMessageBox *msg = new QMessageBox(this);
    msg->setWindowTitle(tr(""));
    msg->setText(tr("Clear all current messages?"));
    msg->setIcon(QMessageBox::Question);
    QPushButton *sureBtn = msg->addButton(tr("Yes"),QMessageBox::RejectRole);
    msg->addButton(tr("No"),QMessageBox::AcceptRole);
    msg->exec();

    if((QPushButton*)msg->clickedButton() == sureBtn) {
        this->m_chat->m_chatMsgModel->clearChatMsg();
        return ;
    }

    return ;
}

// 批量删除消息
void ChatSearch::showChooseMsg()
{
    m_chooseDeleWid->show();
    m_sureDeleBtn->show();
    m_cancelDeleBtn->show();
    m_allBtn->hide();
    m_fileBtn->hide();
    m_ImageBtn->hide();
    m_linkBtn->hide();
    m_deleMenuBtn->hide();

    showDeleMsgCheckbox();
    //从底部开始显示
    setScrollToBottom();
}

//checkbox选择要删除的信息
void ChatSearch::slotChooseMsg(const QModelIndex &)
{
    if (m_chooseDeleWid->isHidden()) {
        return;
    } else {
        QModelIndex modelRow;
        modelRow = m_listView->selectionModel()->currentIndex();//获取listview最近行号
        int itemRow = modelRow.row();

        QListWidgetItem *item = m_chooseListWid->item(itemRow);
        QWidget *chooseWid = static_cast<QWidget *>(m_chooseListWid->itemWidget(item));
        QCheckBox *box = chooseWid->findChild<QCheckBox *>();
        box->click();
    }
    return;
}

//创建删除时复选框
void ChatSearch::showDeleMsgCheckbox()
{
    if (m_chooseListWid != nullptr) {
        delete m_chooseListWid;
        m_chooseListWid = nullptr;
    }
    m_chooseListWid = new QListWidget(m_chooseDeleWid);
    m_chooseListWid->show();

    int count  = m_listView->model()->rowCount();
    for(int i = 0; i < count; i++)
        {
            QListWidgetItem *item = new QListWidgetItem();
            item->setSizeHint(QSize(16, 80));
            item->setFlags(Qt::ItemIsEnabled);

            QString listStyle;
            if (GlobalSizeData::THEME_COLOR == GlobalSizeData::UKUILight) {
                listStyle = "QListWidget{background-color:#FFFFFF;}"
                                    "QListWidget::item:hover{background-color:#FFFFFF;}"
                                    "QListWidget::item::selected:active{background-color:#FFFFFF;border-width:0;}"
                                    "QListWidget::item:selected{background-color:#FFFFFF;border-width:0;}";
                m_chooseListWid->setStyleSheet(listStyle);
            } else {
                listStyle = "QListWidget{background-color:#333333;}"
                            "QListWidget::item:hover{background-color:#333333;}"
                            "QListWidget::item::selected:active{background-color:#333333;border-width:0;}"
                            "QListWidget::item:selected{background-color:#333333;border-width:0;}";
                m_chooseListWid->setStyleSheet(listStyle);
            }


            QWidget *m_checkWidget = new QWidget();
            QCheckBox *m_chooseDeleBox = new QCheckBox(m_checkWidget);
            m_chooseDeleBox->setFixedSize(QSize(16, 16));

            //设置项中的复选框位置
            QHBoxLayout *hLayout;
            hLayout = new QHBoxLayout();
            hLayout->addStretch();
            hLayout->addWidget(m_chooseDeleBox);
            hLayout->addStretch();
            hLayout->setMargin(0);
            QVBoxLayout *vLayout;
            vLayout = new QVBoxLayout();
            vLayout->addStretch();
            vLayout->addLayout(hLayout);
            vLayout->addStretch();
            vLayout->setSpacing(7);
            vLayout->setMargin(0);
            m_checkWidget->setLayout(vLayout);

            m_chooseListWid->addItem(item);//在ListWidget中添加一个条目
            m_chooseListWid->setItemWidget(item, m_checkWidget);//在这个条目中放置CheckBox

        }
    //选择删除的列表
    m_chooseListWid->setFixedHeight(520);
    m_chooseListWid->setFixedWidth(25);
    //m_chooseListWid->setSpacing(7);
    m_chooseListWid->setDragEnabled(false);
    m_chooseListWid->setFrameShape(QListView::NoFrame);
    m_chooseListWid->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_chooseListWid->setContextMenuPolicy(Qt::CustomContextMenu);
    m_chooseListWid->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    m_chooseListWid->verticalScrollBar()->setProperty("drawScrollBarGroove", false);
    m_chooseListWid->scrollToBottom();
    m_chooseListWid->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//    m_chooseListWid->hide();

    connect(m_chooseListWid->verticalScrollBar(),SIGNAL(valueChanged(int)), this, SLOT(onSliderMoved(int)));

    return;
}

// 取消删除消息
void ChatSearch::slotCancelClick()
{
    if (m_chooseListWid != nullptr) {
        delete m_chooseListWid;
        m_chooseListWid = nullptr;
    }

    m_chooseDeleWid->hide();
    m_sureDeleBtn->hide();
    m_cancelDeleBtn->hide();
    m_allBtn->show();
    m_fileBtn->show();
    m_ImageBtn->show();
    m_linkBtn->show();
    m_deleMenuBtn->show();
}

// 确定删除消息
void ChatSearch::slotSureClick()
{
    QMessageBox *msg = new QMessageBox(this);
    msg->setWindowTitle(tr(""));
    msg->setText(tr("Delete the currently selected message?"));
    msg->setIcon(QMessageBox::Question);
    QPushButton *sureBtn = msg->addButton(tr("Yes"), QMessageBox::RejectRole);
    msg->addButton(tr("No"), QMessageBox::AcceptRole);
    msg->exec();

    if ((QPushButton*)msg->clickedButton() != sureBtn) {
        return ;
    }

    for(int i = 0; i < m_chooseListWid->count(); i++) {
        QListWidgetItem *item = m_chooseListWid->item(i);

        //将QWidget 转化为QCheckBox  获取第i个item 的控件
        QWidget *chooseWid = static_cast<QWidget *>(m_chooseListWid->itemWidget(item));
        QCheckBox *box = chooseWid->findChild<QCheckBox *>();
        if(box->isChecked()) {

            QModelIndex searchIndex = m_listView->model()->index(i,0);
            // 获取消息ID号
            int searchMsgId = searchIndex.data(ChatMsgModel::MsgId).toInt();

            this->m_chat->m_chatMsgModel->delSearchMsg(searchMsgId);

            this->m_chooseListWid->takeItem(i);
            i = 0;
        }
    }
    slotCancelClick();
    return ;
}
