#include "chat_search_filter.h"
#include "model/chatmsgmodel.h"

#include <QFileInfo>
#include <QDateTime>

#define MEM_BUF 1024 * 4

ChatSearchFilter::ChatSearchFilter() {}

ChatSearchFilter::~ChatSearchFilter() {}

/* 按照时间顺序 从小到大 */
bool ChatSearchFilter::lessThan(const QModelIndex &source_left, const QModelIndex &source_right) const
{
    QString dateLeft = source_left.data(ChatMsgModel::ChatMsgRoles::MsgTime).toString();
    QString dateRight = source_right.data(ChatMsgModel::ChatMsgRoles::MsgTime).toString();

    if (dateLeft > dateRight) {
        return false;
    }

    return true;
}


/*
 * pat : all:xx , file : xx , image : xx , link : xx
 */
bool ChatSearchFilter::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const
{
    QModelIndex index = sourceModel()->index(sourceRow, 0, sourceParent);

    int msgType = index.data(ChatMsgModel::ChatMsgRoles::MsgType).toInt();
    QString chatText = index.data(ChatMsgModel::ChatMsgRoles::MsgContent).toString();
    QString filePath = index.data(ChatMsgModel::ChatMsgRoles::FilePath).toString();
    QString fileName = QFileInfo(filePath).fileName();

    /* 过滤时间 item */
    if (msgType == ChatMsgModel::MessageType::TimeMsg) {
        return false;
    }

    /* 如果过滤的内容为空 , 全部返回 , 不进行过滤 */
    QRegExp a = this->filterRegExp();
    QString pat = a.pattern();
    if (pat.isEmpty()) {
        return true;
    }

    QStringList res = pat.split(':');
    if (res.count() != 2) {
        qDebug() << "Error : filter pattern error";
        return false;
    }

    /* 判断是否为 all */
    if (res.at(0) == QString("all")) {
        if (res.at(1) == QString("")) {
            return true;
        } else {
            if (chatText.contains(res.at(1)) || fileName.contains(res.at(1))) {
                return true;
            }
        }

        return false;
    }

    /* 判断是否为 file */
    if (res.at(0) == QString("file")) {
        if (msgType == ChatMsgModel::MessageType::FileMsg) {
            if (!this->judgeWhetherPicture(filePath)) {
                if (res.at(1) == QString("")) {
                    return true;
                } else {
                    if (fileName.contains(res.at(1))) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /* 判断是否为 image */
    if (res.at(0) == QString("image")) {
        if (msgType == ChatMsgModel::MessageType::FileMsg) {
            if (this->judgeWhetherPicture(filePath)) {
                if (res.at(1) == QString("")) {
                    return true;
                } else {
                    if (fileName.contains(res.at(1))) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /* 判断是否为 link */
    if (res.at(0) == QString("link")) {
        if (msgType != ChatMsgModel::MessageType::FileMsg) {
            if (this->judgeWhetherLink(chatText)) {
                if (res.at(1) == QString("")) {
                    return true;
                } else {
                    if (chatText.contains(res.at(1))) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    return false;
}

/*
 * PRO
 * if file is image return true , other return false
 */
bool ChatSearchFilter::judgeWhetherPicture(QString path) const
{
    //    QStringList imageList;
    //    imageList.clear();
    //    imageList << "png" << "gif" << "jpg" << "jpeg" << "svg" << "tif" << "bmp" << "ico" << "psd"
    //              << "swf" << "pcx" << "dxf" << "wmf" << "emf" << "lic" << "eps" << "tga";
    //    QStringList videoList;
    //    videoList.clear();
    //    videoList << "3gp" << "asf" << "flv" << "mpg" << "vob" << "mp4" << "mkv" << "mov" << "rm"
    //              << "rmvb" << "wmv" << "asx" << "m4v" << "avi" << "dat";

    //    QStringList res;
    //    res.clear();
    //    res = path.split('.');
    //    int count = res.count();
    //    for (int i = 0; i < imageList.count(); i++) {
    //        if (res.at(count - 1) == imageList.at(i)) {
    //            return true;
    //        }
    //    }
    //    for (int i = 0; i < videoList.count(); i++) {
    //        if (res.at(count - 1) == videoList.at(i)) {
    //            return true;
    //        }
    //    }

    //    return false;

    char buf[MEM_BUF];
    memset(buf, 0x00, sizeof(buf));

    std::string stdPath = path.toStdString();
    const char *cPath = stdPath.c_str();

    sprintf(buf, "file '%s'", cPath);

    FILE *fd = NULL;
    fd = popen(buf, "r");
    if (fd == NULL) {
        printf("Error : exec command fail");
        return false;
    }

    char res[MEM_BUF];
    memset(res, 0x00, sizeof(res));

    while (fgets(res, sizeof(res), fd) != NULL) {
        if ((strstr(res, "image") != NULL) || (strstr(res, "Matroska data") != NULL)
            || (strstr(res, "ISO Media") != NULL) || (strstr(res, "PC bitmap"))
            || (strstr(res, "MS Windows icon resource - 1 icon"))
            || (strstr(res, "Scalable Vector Graphics image") != NULL) || (strstr(res, "Microsoft ASF"))
            || (strstr(res, "RealMedia file")) || (strstr(res, "Macromedia Flash Video"))
            || (strstr(res, "MPEG sequence")) || (strstr(res, "JVT NAL sequence"))
            || (strstr(res, "Macromedia Flash data")) || (strstr(res, "RIFF (little-endian) data"))
            || (strstr(res, "Targa image data - Map 63679 x 65536 x 1 +260 +38400 - 11-bit alpha - top - right - four "
                            "way interleave"))
            || (strstr(res, "MPEG transport stream data")) || (strstr(res, "WebM"))) {
            pclose(fd);

            return true;
        }

        memset(res, 0x00, sizeof(res));
    }

    pclose(fd);

    QStringList list;
    list = path.split(".");
    if ((list.at(list.size() - 1) == "ts") || (list.at(list.size() - 1) == "m2t")
        || (list.at(list.size() - 1) == "m2ts")) {
        return true;
    }

    return false;
}

bool ChatSearchFilter::judgeWhetherLink(QString str) const
{
    QString pat("(https?|ftp|file)://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]");

    QRegExp reg(pat);

    if (reg.exactMatch(str)) {
        return true;
    }

    return false;
}
