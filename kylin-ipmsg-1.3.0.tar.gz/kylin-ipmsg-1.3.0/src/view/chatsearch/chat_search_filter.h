#ifndef __CHAT_SEARCH_FILTER_H__
#define __CHAT_SEARCH_FILTER_H__

#include <QSortFilterProxyModel>

class ChatSearchFilter : public QSortFilterProxyModel
{
    Q_OBJECT

public:
    ChatSearchFilter();
    ~ChatSearchFilter();

protected:
     bool filterAcceptsRow(int source_row , const QModelIndex &source_parent) const;
     bool lessThan(const QModelIndex &source_left, const QModelIndex &source_right) const;
     bool judgeWhetherPicture(QString path) const;
     bool judgeWhetherLink(QString str) const;

private:

signals:

public slots:

};

#endif
